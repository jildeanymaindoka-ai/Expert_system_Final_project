"""
Chatbot RAG - Panduan UNKLAB 2024
Menggunakan Gradio + Google Gemini API
"""

import os
import re
import json
import math
import gradio as gr
import google.generativeai as genai
from pypdf import PdfReader

# ─────────────────────────────────────────────
# 1. KONFIGURASI
# ─────────────────────────────────────────────
PDF_PATH = "BUKU-PANDUAN-UNKLAB-2024.pdf"   # letakkan PDF di folder yang sama
CHUNK_SIZE = 600        # kata per chunk
CHUNK_OVERLAP = 80      # kata overlap antar chunk
TOP_K = 5               # jumlah chunk teratas yang diambil
EMBED_MODEL = "models/text-embedding-004"
CHAT_MODEL  = "gemini-1.5-flash"

# ─────────────────────────────────────────────
# 2. EKSTRAKSI & CHUNKING PDF
# ─────────────────────────────────────────────

def extract_text_from_pdf(path: str) -> str:
    reader = PdfReader(path)
    pages_text = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        text = text.strip()
        if text:
            pages_text.append(f"[Halaman {i+1}]\n{text}")
    return "\n\n".join(pages_text)


def split_into_chunks(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP):
    words = text.split()
    chunks = []
    step = chunk_size - overlap
    for start in range(0, len(words), step):
        end = start + chunk_size
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        if end >= len(words):
            break
    return chunks


# ─────────────────────────────────────────────
# 3. VECTOR STORE (kosinus sederhana, tanpa lib external)
# ─────────────────────────────────────────────

def cosine_similarity(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class VectorStore:
    def __init__(self):
        self.chunks: list[str] = []
        self.embeddings: list[list[float]] = []

    def add(self, chunks: list[str], embed_fn):
        print(f"  Membuat embedding untuk {len(chunks)} chunk...")
        batch_size = 20
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            result = genai.embed_content(
                model=EMBED_MODEL,
                content=batch,
                task_type="retrieval_document"
            )
            self.embeddings.extend(result["embedding"])
            self.chunks.extend(batch)
            print(f"  Progress: {min(i + batch_size, len(chunks))}/{len(chunks)}")

    def search(self, query: str, top_k: int = TOP_K) -> list[str]:
        q_emb = genai.embed_content(
            model=EMBED_MODEL,
            content=query,
            task_type="retrieval_query"
        )["embedding"]
        scores = [(cosine_similarity(q_emb, emb), chunk)
                  for emb, chunk in zip(self.embeddings, self.chunks)]
        scores.sort(key=lambda x: x[0], reverse=True)
        return [chunk for _, chunk in scores[:top_k]]


# ─────────────────────────────────────────────
# 4. INISIALISASI GLOBAL
# ─────────────────────────────────────────────
vector_store = VectorStore()
gemini_chat_model = None
init_status = {"done": False, "error": None}


def initialize(api_key: str):
    """Inisialisasi Gemini + bangun vector store dari PDF."""
    global gemini_chat_model, init_status

    if not api_key.strip():
        return "❌ API Key tidak boleh kosong."

    if not os.path.exists(PDF_PATH):
        return f"❌ File PDF tidak ditemukan: {PDF_PATH}\nPastikan file ada di folder yang sama dengan app.py"

    try:
        # Konfigurasi Gemini
        genai.configure(api_key=api_key.strip())
        gemini_chat_model = genai.GenerativeModel(CHAT_MODEL)

        # Test API key
        genai.embed_content(
            model=EMBED_MODEL,
            content="test",
            task_type="retrieval_query"
        )

        print("✅ API Key valid. Memproses PDF...")
        print(f"  Mengekstrak teks dari {PDF_PATH}...")
        text = extract_text_from_pdf(PDF_PATH)
        print(f"  Total karakter: {len(text)}")

        chunks = split_into_chunks(text)
        print(f"  Total chunk: {len(chunks)}")

        vector_store.add(chunks, None)

        init_status = {"done": True, "error": None}
        return f"✅ Berhasil! {len(chunks)} chunk diindeks dari {PDF_PATH}.\nChatbot siap digunakan."

    except Exception as e:
        init_status = {"done": False, "error": str(e)}
        return f"❌ Error: {str(e)}"


# ─────────────────────────────────────────────
# 5. RAG CHAT
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """Kamu adalah asisten panduan akademik Universitas Klabat (UNKLAB).
Jawablah pertanyaan mahasiswa dengan ramah, jelas, dan akurat berdasarkan konteks dari Buku Panduan UNKLAB 2024 yang diberikan.

Aturan:
- Jawab HANYA berdasarkan konteks yang diberikan.
- Jika informasi tidak ada di konteks, katakan dengan jujur bahwa kamu tidak menemukan informasinya di buku panduan.
- Gunakan bahasa Indonesia yang sopan dan mudah dipahami.
- Jika relevan, sebutkan nomor halaman yang ada di konteks.
- Jangan mengarang informasi yang tidak ada di konteks.
"""

def chat(message: str, history: list):
    if not init_status["done"]:
        yield "⚠️ Chatbot belum diinisialisasi. Silakan masukkan API Key Gemini dan klik **Inisialisasi** terlebih dahulu."
        return

    if not message.strip():
        yield "Silakan ketik pertanyaan Anda."
        return

    try:
        # Ambil konteks relevan
        relevant_chunks = vector_store.search(message, top_k=TOP_K)
        context = "\n\n---\n\n".join(relevant_chunks)

        # Bangun prompt
        full_prompt = f"""{SYSTEM_PROMPT}

=== KONTEKS DARI BUKU PANDUAN UNKLAB 2024 ===
{context}
=== AKHIR KONTEKS ===

Pertanyaan mahasiswa: {message}

Jawaban:"""

        # Streaming response
        response = gemini_chat_model.generate_content(
            full_prompt,
            stream=True,
            generation_config=genai.GenerationConfig(
                temperature=0.2,
                max_output_tokens=1024,
            )
        )

        partial = ""
        for chunk in response:
            if chunk.text:
                partial += chunk.text
                yield partial

    except Exception as e:
        yield f"❌ Error saat memproses pertanyaan: {str(e)}"


# ─────────────────────────────────────────────
# 6. ANTARMUKA GRADIO
# ─────────────────────────────────────────────

CSS = """
#chatbot-container { border-radius: 12px; }
.contain { max-width: 900px; margin: auto; }
#title-row { text-align: center; margin-bottom: 8px; }
#status-box { font-size: 13px; }
footer { display: none !important; }
"""

CONTOH_PERTANYAAN = [
    "Apa visi dan misi UNKLAB?",
    "Bagaimana prosedur pengambilan cuti akademik?",
    "Apa saja persyaratan kelulusan mahasiswa?",
    "Jelaskan tentang sistem SKS di UNKLAB",
    "Bagaimana cara mengajukan beasiswa?",
    "Apa itu program MBKM di UNKLAB?",
    "Bagaimana tata tertib kehidupan kampus?",
    "Apa saja fasilitas yang tersedia di UNKLAB?",
]

with gr.Blocks(css=CSS, title="Chatbot Panduan UNKLAB 2024", theme=gr.themes.Soft()) as demo:

    gr.HTML("""
    <div id="title-row">
        <h1 style="color:#1a3c6e; font-size:2em; margin-bottom:4px;">
            🎓 Chatbot Panduan UNKLAB 2024
        </h1>
        <p style="color:#555; font-size:0.95em;">
            Asisten AI berbasis RAG — sumber: <strong>Buku Panduan Universitas Klabat 2024</strong>
        </p>
    </div>
    """)

    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### ⚙️ Pengaturan")
            api_key_input = gr.Textbox(
                label="Google Gemini API Key",
                placeholder="Masukkan API Key Anda...",
                type="password",
                info="Dapatkan di: https://aistudio.google.com/app/apikey"
            )
            init_btn = gr.Button("🚀 Inisialisasi Chatbot", variant="primary", size="lg")
            status_output = gr.Textbox(
                label="Status",
                lines=3,
                interactive=False,
                elem_id="status-box",
                value="Belum diinisialisasi. Masukkan API Key lalu klik Inisialisasi."
            )

            gr.Markdown("---")
            gr.Markdown("### 💡 Contoh Pertanyaan")
            for q in CONTOH_PERTANYAAN:
                gr.Button(q, size="sm", variant="secondary")

        with gr.Column(scale=3):
            chatbot = gr.Chatbot(
                label="Chat dengan Panduan UNKLAB",
                height=520,
                bubble_full_width=False,
                elem_id="chatbot-container",
                avatar_images=(
                    None,
                    "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Universitas_Klabat_Logo.png/200px-Universitas_Klabat_Logo.png"
                ),
                placeholder="<br><br><center><b>🎓 Chatbot siap setelah inisialisasi</b><br>Tanyakan apa saja tentang Panduan UNKLAB 2024</center>"
            )

            with gr.Row():
                msg_input = gr.Textbox(
                    placeholder="Ketik pertanyaan Anda di sini...",
                    scale=5,
                    show_label=False,
                    container=False
                )
                send_btn = gr.Button("Kirim ➤", variant="primary", scale=1)

            clear_btn = gr.Button("🗑️ Hapus Riwayat Chat", size="sm")

    gr.Markdown("""
    ---
    <center style="color:#888; font-size:12px;">
    Chatbot ini menjawab berdasarkan Buku Panduan UNKLAB 2024 saja.
    Untuk informasi terkini, hubungi langsung bagian akademik UNKLAB.
    </center>
    """)

    # ── Event Handlers ──────────────────────────
    def user_submit(message, history):
        return "", history + [[message, None]]

    def bot_respond(history):
        if not history:
            return history
        message = history[-1][0]
        history[-1][1] = ""
        for partial_response in chat(message, history[:-1]):
            history[-1][1] = partial_response
            yield history

    def add_example(example_btn, history):
        return history + [[example_btn, None]]

    init_btn.click(
        fn=initialize,
        inputs=[api_key_input],
        outputs=[status_output]
    )

    msg_input.submit(
        fn=user_submit,
        inputs=[msg_input, chatbot],
        outputs=[msg_input, chatbot]
    ).then(
        fn=bot_respond,
        inputs=[chatbot],
        outputs=[chatbot]
    )

    send_btn.click(
        fn=user_submit,
        inputs=[msg_input, chatbot],
        outputs=[msg_input, chatbot]
    ).then(
        fn=bot_respond,
        inputs=[chatbot],
        outputs=[chatbot]
    )

    clear_btn.click(fn=lambda: [], outputs=[chatbot])

    # Tombol contoh pertanyaan
    for i, btn in enumerate(demo.blocks.values()):
        pass  # handled below via gr.Examples

if __name__ == "__main__":
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True
    )
