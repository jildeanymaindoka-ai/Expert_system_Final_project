# 🎓 Chatbot RAG — Panduan UNKLAB 2024

Chatbot berbasis **Retrieval-Augmented Generation (RAG)** yang menjawab pertanyaan berdasarkan **Buku Panduan Universitas Klabat (UNKLAB) 2024**.

---

## 📁 Struktur Folder

```
unklab_chatbot/
├── app.py                        ← Kode utama aplikasi
├── requirements.txt              ← Daftar dependensi
├── README.md                     ← File ini
└── BUKU-PANDUAN-UNKLAB-2024.pdf  ← ⚠️ Letakkan PDF di sini!
```

---

## ⚡ Cara Menjalankan

### 1. Persiapkan folder
Pastikan file `BUKU-PANDUAN-UNKLAB-2024.pdf` berada **di dalam folder yang sama** dengan `app.py`.

### 2. Install dependensi
Buka terminal di folder `unklab_chatbot/`, lalu jalankan:
```bash
pip install -r requirements.txt
```

### 3. Jalankan aplikasi
```bash
python app.py
```

### 4. Buka browser
Akses di: **http://localhost:7860**

---

## 🔑 Mendapatkan Gemini API Key

1. Buka https://aistudio.google.com/app/apikey
2. Klik **Create API Key**
3. Salin API Key tersebut
4. Tempelkan di kolom API Key pada aplikasi
5. Klik **Inisialisasi Chatbot**

> ⏳ Proses inisialisasi pertama membutuhkan waktu beberapa menit karena memproses 351 halaman PDF.

---

## 🧠 Cara Kerja (RAG)

```
PDF ──► Ekstraksi Teks ──► Chunking ──► Embedding (Gemini)
                                              │
Pertanyaan ──► Embedding ──► Cosine Similarity Search
                                              │
                              Top-5 Chunk Relevan
                                              │
                         Gemini 1.5 Flash ──► Jawaban
```

1. **Ekstraksi**: Teks dari 351 halaman PDF diekstrak
2. **Chunking**: Dipecah menjadi potongan ~600 kata dengan overlap 80 kata
3. **Embedding**: Setiap chunk diubah menjadi vektor menggunakan `text-embedding-004`
4. **Retrieval**: Saat ada pertanyaan, 5 chunk paling relevan diambil via cosine similarity
5. **Generation**: Gemini 1.5 Flash menjawab berdasarkan konteks yang ditemukan

---

## ⚙️ Konfigurasi (opsional)

Edit bagian ini di `app.py` untuk menyesuaikan:

```python
CHUNK_SIZE    = 600   # kata per chunk (lebih besar = konteks lebih panjang)
CHUNK_OVERLAP = 80    # overlap antar chunk (cegah potongan informasi)
TOP_K         = 5     # jumlah chunk yang diambil per pertanyaan
```

---

## 📝 Catatan

- Jawaban hanya berdasarkan isi Buku Panduan UNKLAB 2024
- Tidak memerlukan internet setelah inisialisasi (kecuali Gemini API)
- Riwayat chat tidak disimpan permanen
- Untuk informasi terkini, hubungi bagian akademik UNKLAB
